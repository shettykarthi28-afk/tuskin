// Mobile menu
const nav = document.getElementById("nav");
document.getElementById("menuToggle").addEventListener("click", () => nav.classList.toggle("open"));
document.querySelectorAll("#navLinks a").forEach(a => a.addEventListener("click", () => nav.classList.remove("open")));
window.addEventListener("scroll", () => nav.classList.toggle("scrolled", window.scrollY > 20), { passive: true });

// Scroll reveal with stagger
const io = new IntersectionObserver(entries => {
  entries.forEach(entry => {
    if (!entry.isIntersecting) return;
    const siblings = [...entry.target.parentElement.children].filter(el => el.classList.contains("reveal"));
    entry.target.style.transitionDelay = `${Math.min(siblings.indexOf(entry.target), 6) * 80}ms`;
    entry.target.classList.add("in");
    io.unobserve(entry.target);
  });
}, { threshold: 0.15 });
document.querySelectorAll(".reveal").forEach(el => io.observe(el));

// Count-up stats
const countIO = new IntersectionObserver(entries => {
  entries.forEach(entry => {
    if (!entry.isIntersecting) return;
    const el = entry.target;
    const target = parseFloat(el.dataset.count);
    const decimals = parseInt(el.dataset.decimal || "0", 10);
    const start = performance.now();
    const tick = now => {
      const p = Math.min((now - start) / 1600, 1);
      el.textContent = (target * (1 - Math.pow(1 - p, 3))).toFixed(decimals);
      if (p < 1) requestAnimationFrame(tick);
    };
    requestAnimationFrame(tick);
    countIO.unobserve(el);
  });
}, { threshold: 0.6 });
document.querySelectorAll("[data-count]").forEach(el => countIO.observe(el));

const finePointer = window.matchMedia("(pointer: fine)").matches;
const reduceMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;

if (finePointer && !reduceMotion) {
  // Cursor glow
  const glow = document.querySelector(".cursor-glow");
  window.addEventListener("mousemove", e => {
    glow.style.left = `${e.clientX}px`;
    glow.style.top = `${e.clientY}px`;
  });

  // 3D tooth follows the cursor
  const tooth = document.getElementById("tooth");
  document.getElementById("heroVisual").addEventListener("mousemove", e => {
    const r = e.currentTarget.getBoundingClientRect();
    const x = (e.clientX - r.left) / r.width - 0.5;
    const y = (e.clientY - r.top) / r.height - 0.5;
    tooth.style.transform = `rotateY(${x * 30}deg) rotateX(${-y * 30}deg)`;
  });
  document.getElementById("heroVisual").addEventListener("mouseleave", () => (tooth.style.transform = ""));

  // Tilt cards
  document.querySelectorAll(".tilt").forEach(card => {
    card.addEventListener("mousemove", e => {
      const r = card.getBoundingClientRect();
      const x = (e.clientX - r.left) / r.width - 0.5;
      const y = (e.clientY - r.top) / r.height - 0.5;
      card.style.transform = `perspective(700px) rotateY(${x * 12}deg) rotateX(${-y * 12}deg) translateY(-6px)`;
    });
    card.addEventListener("mouseleave", () => (card.style.transform = ""));
  });
}

// Before / after slider
const compare = document.getElementById("compare");
document.getElementById("compareRange").addEventListener("input", e => compare.style.setProperty("--pos", `${e.target.value}%`));

// Booking date: no past dates
const dateInput = document.getElementById("dateInput");
const today = new Date();
dateInput.min = new Date(today.getTime() - today.getTimezoneOffset() * 60000).toISOString().split("T")[0];

// Booking form (Netlify Forms via AJAX)
const form = document.getElementById("bookingForm");
const note = document.getElementById("formNote");
const submitBtn = document.getElementById("submitBtn");
form.addEventListener("submit", async e => {
  e.preventDefault();
  const picked = new Date(dateInput.value + "T00:00:00");
  if (picked.getDay() === 2) {
    note.textContent = "The clinic is closed on Tuesdays — please pick another day.";
    note.className = "form-note err";
    return;
  }
  submitBtn.disabled = true;
  submitBtn.textContent = "Sending…";
  try {
    const res = await fetch("/", {
      method: "POST",
      headers: { "Content-Type": "application/x-www-form-urlencoded" },
      body: new URLSearchParams(new FormData(form)).toString(),
    });
    if (!res.ok) throw new Error(res.statusText);
    window.location.href = "/thank-you";
  } catch {
    note.textContent = "Something went wrong. Please call or WhatsApp us at +91 80880 63142.";
    note.className = "form-note err";
    submitBtn.disabled = false;
    submitBtn.textContent = "Confirm Booking Request";
  }
});

document.getElementById("year").textContent = new Date().getFullYear();
